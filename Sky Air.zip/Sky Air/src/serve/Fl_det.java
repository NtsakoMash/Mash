package serve;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

/**
 * Servlet implementation class Fl_det
 */
public class Fl_det extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Fl_det() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String bookingotp=request.getParameter("book1");
		String fl_id=request.getParameter("fl")+"_"+bookingotp;
		String aiprice=request.getParameter("aiprice");
		String japrice=request.getParameter("japrice");
		String igprice=request.getParameter("igprice");
		String sjprice=request.getParameter("sjprice");
		String adult=request.getParameter("ADULT");
		String children=request.getParameter("CHILDREN");
		String infants=request.getParameter("INFANTS");
		String class1=request.getParameter("CLASS");
		String from=request.getParameter("FROM");
		String to=request.getParameter("TO");
		String pc=request.getParameter("PC");
		String day=request.getParameter("DAY");
		String flight=request.getParameter("fl");
		String bd=request.getParameter("BD");
		String ai_time=request.getParameter("airI1");
		String ja_time=request.getParameter("jetA1");
		String ig_time=request.getParameter("indiG1");
		String sj_time=request.getParameter("spiceJ1");
		
		
		String aseat=request.getParameter("aseat");
		String jseat=request.getParameter("jseat");
		String iseat=request.getParameter("iseat");
		String sseat=request.getParameter("sseat");
		
		
		int ad=Integer.parseInt(adult);
		int ch=Integer.parseInt(children);
		int in=Integer.parseInt(infants);
		int passen=ad+ch+in;
		
		int aseat1=Integer.parseInt(aseat);
		int jseat1=Integer.parseInt(jseat);
		int iseat1=Integer.parseInt(iseat);
		int sseat1=Integer.parseInt(sseat);
		
		int avseat=0;
		
		String time1=null;
		
		
		
		
		
		String price=null;
		if(request.getParameter("fl").equals("AirIndia")){
			price=aiprice;
			time1=ai_time;
			avseat=aseat1-passen;
		}
		else if(request.getParameter("fl").equals("Jet Airways")){
			price=japrice;
			time1=ja_time;
			avseat=jseat1-passen;
		}
		if(request.getParameter("fl").equals("IndiGo")){
			price=igprice;
			time1=ig_time;
			avseat=iseat1-passen;
		}
		if(request.getParameter("fl").equals("SpiceJet")){
			price=sjprice;
			time1=sj_time;
			avseat=sseat1-passen;
		}
		
		
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		java.sql.Connection conn = null;
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/airdb [airdb]");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		java.sql.Statement st = null;
		try {
			st = conn.createStatement();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ResultSet rs=null;
		try{
			rs = st.executeQuery("select * from pd_fl_pay where bookingno='"+bookingotp+"'");
		}catch(Exception e){
			e.printStackTrace();
		}

		try {
			if(rs.next()){
				
				try {
					int i= st.executeUpdate("update pd_fl_pay set fl_id='"+fl_id+"' where bookingno='"+bookingotp+"'");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					int i2=st.executeUpdate("update pd_fl_pay set price='"+price+"' where bookingno='"+bookingotp+"'");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
					
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

		java.sql.Statement st11 = null;
		try {
			st11 = conn.createStatement();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ResultSet rs11=null;
		try{
			rs11 = st11.executeQuery("select * from booking1 where bookingno='"+bookingotp+"'");
		}catch(Exception e){
			e.printStackTrace();
		}

		try {
			if(rs11.next()){
				int i= st11.executeUpdate("update booking1 set time='"+time1+"' where bookingno='"+bookingotp+"'");
				
			}else{
				rs11 = st11.executeQuery("select * from booking2 where bookingno='"+bookingotp+"'");
				if(rs11.next()){
					int i= st11.executeUpdate("update booking2 set time='"+time1+"' where bookingno='"+bookingotp+"'");
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
		java.sql.Statement st0 = null;
		try {
			st0 = conn.createStatement();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ResultSet rs0=null;
		try{
			rs0 = st0.executeQuery("select * from seats where date='"+bd+"' and from_s='"+from+"' and to_d='"+to+"'");
		}catch(Exception e){
			e.printStackTrace();
		}

		try {
			if(rs0.next()){
				
				
				if(flight.equals("AirIndia")){
					int i= st0.executeUpdate("update seats set ai='"+avseat+"' where date='"+bd+"' and from_s='"+from+"' and to_d='"+to+"'");
				}
				else if(flight.equals("Jet Airways")){
					int i= st0.executeUpdate("update seats set ja='"+avseat+"' where date='"+bd+"' and from_s='"+from+"' and to_d='"+to+"'");
				}
				else if(flight.equals("IndiGo")){
					int i= st0.executeUpdate("update seats set ig='"+avseat+"' where date='"+bd+"' and from_s='"+from+"' and to_d='"+to+"'");
				}
				else if(flight.equals("SpiceJet")){
					int i= st0.executeUpdate("update seats set sj='"+avseat+"' where date='"+bd+"' and from_s='"+from+"' and to_d='"+to+"'");
				}
				
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
								
		request.setAttribute("price",price);
		
		request.setAttribute("adult",adult);
		request.setAttribute("children",children);
		request.setAttribute("infants",infants);
		request.setAttribute("class1",class1);
		request.setAttribute("from",from);
		request.setAttribute("to",to);
		request.setAttribute("flight",flight);
		request.setAttribute("pc",pc);
		request.setAttribute("day",day);
		request.setAttribute("bd",bd);
		request.setAttribute("time",time1);
		request.setAttribute("bookingotp",bookingotp);
		request.getRequestDispatcher("billing.jsp").forward(request, response);
	}
	
}


