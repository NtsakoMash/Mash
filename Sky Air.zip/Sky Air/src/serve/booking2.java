package serve;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.sql.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class booking2
 */
public class booking2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public booking2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String from=request.getParameter("from");
		String to=request.getParameter("to");
		String dd1=request.getParameter("dd1");
		String dd20=request.getParameter("dd2");
		String dd3=request.getParameter("dd3");
		String pc=request.getParameter("pc");
		String class1=request.getParameter("class1");
		String ad1=request.getParameter("ad1");
		String ad20=request.getParameter("ad2");
		String ad3=request.getParameter("ad3");
		String bookingno=request.getParameter("book");
		
		
		String dd2=null;
		if(dd20.equals("01"))
			dd2="January";
		else if(dd20.equals("02"))
			dd2="February";
		else if(dd20.equals("03"))
			dd2="March";
		else if(dd20.equals("04"))
			dd2="April";
		else if(dd20.equals("05"))
			dd2="May";
		else if(dd20.equals("06"))
			dd2="June";
		else if(dd20.equals("07"))
			dd2="July";
		else if(dd20.equals("08"))
			dd2="August";
		else if(dd20.equals("09"))
			dd2="September";
		else if(dd20.equals("10"))
			dd2="October";
		else if(dd20.equals("11"))
			dd2="November";
		else if(dd20.equals("12"))
			dd2="December";
		
		
		
		String ad2=null;
		if(ad20.equals("01"))
			ad2="January";
		else if(ad20.equals("02"))
			ad2="February";
		else if(ad20.equals("03"))
			ad2="March";
		else if(ad20.equals("04"))
			ad2="April";
		else if(ad20.equals("05"))
			ad2="May";
		else if(ad20.equals("06"))
			ad2="June";
		else if(ad20.equals("07"))
			ad2="July";
		else if(ad20.equals("08"))
			ad2="August";
		else if(ad20.equals("09"))
			ad2="September";
		else if(ad20.equals("10"))
			ad2="October";
		else if(ad20.equals("11"))
			ad2="November";
		else if(ad20.equals("12"))
			ad2="December";
		
		
		
		
		
		
		request.setAttribute("bookingotp",bookingno);
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		java.sql.Connection conn = null;
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/airdb [airdb]");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Statement st = null;
		try {
			st = conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ResultSet rs;
		try {
			int i= st.executeUpdate("insert into booking2 values('"+from+"','"+to+"','"+dd1+"','"+dd2+"','"+ad3+"','"+ad1+"','"+ad2+"','"+ad3+"','"+pc+"','"+class1+"','"+"cancelled"+"','"+bookingno+"','"+"null"+"')");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.getRequestDispatcher("passenger_details.jsp").forward(request, response);
		
	}

}
