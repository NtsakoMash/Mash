package serve;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Statement;

/**
 * Servlet implementation class Payment
 */
public class Payment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Payment() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String botp=request.getParameter("botp");
		String p_method=request.getParameter("method");
		String ccardno=request.getParameter("cct");
		String dcardno=request.getParameter("dct");
		String cardno=null;
		if(p_method.equals("Credit Card")) cardno=ccardno;
		else cardno=dcardno;
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		java.sql.Connection conn = null;
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/airdb [airdb]");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		java.sql.Statement st = null;
		try {
			st = conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			ResultSet rs=st.executeQuery("select * from pd_fl_pay where bookingno='"+botp+"'");
			if(rs.next()){
				int i= st.executeUpdate("update pd_fl_pay set method='"+p_method+"' where bookingno='"+botp+"'");
				int i2= st.executeUpdate("update pd_fl_pay set cardno='"+cardno+"' where bookingno='"+botp+"'");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		java.sql.Statement st1 = null;
		try {
			st1 = conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ResultSet rs1 = null;
		try {
			rs1 = st1.executeQuery("select * from booking1 where bookingno='"+botp+"'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			if(rs1.next())
			{
				int i= st1.executeUpdate("update booking1 set status='"+"confirmed"+"'where bookingno='"+botp+"'");
			}else{
				rs1=st1.executeQuery("select * from booking2 where bookingotp='"+botp+"'");
				if(rs1.next())
				{
					int i= st1.executeUpdate("update booking2 set status='"+"confirmed"+"' where bookingno='"+botp+"'");
				}
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setAttribute("botp",botp);
		request.getRequestDispatcher("ticket.jsp").forward(request, response);
		
	}

}
