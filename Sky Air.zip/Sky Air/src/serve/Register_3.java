package serve;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;




/**
 * Servlet implementation class register
 */
public class Register_3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String HttpServletRequest = null;
	private static final String HttpServletResponse = null;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Register_3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String user=request.getParameter("username");
		String password=request.getParameter("password");
		String dob1=request.getParameter("dob1");
		String dob2=request.getParameter("dob2");
		String dob3=request.getParameter("dob3");
		String gender=request.getParameter("gen");
		String address=request.getParameter("address");
		String city=request.getParameter("city");
		String state=request.getParameter("state");

		String sq=request.getParameter("sq");
		String answer=request.getParameter("answer");
		//session.putValue("username",user);
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		java.sql.Connection conn = null;
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/airdb [airdb]");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Statement st = null;
		try {		st = conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ResultSet rs;
		try {
			int i= st.executeUpdate("insert into reg_det values('"+user+"','"+password+"','"+dob1+"','"+dob2+"','"+dob3+"','"+gender+"','"+address+"','"+city+"','"+state+"','"+sq+"','"+answer+"')");
		
			response.getWriter().print("Registered Successfully. Redirecting to login page....");
			response.setHeader("Refresh", "3;url=login.jsp");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			response.getWriter().println("\n Unable to register user: ");
		        String strUserMsg;
				//Check if we are getting duplicate key exception on userName
		        if(e.getMessage().indexOf("Duplicate entry")!=-1) {
		        	response.getWriter().println("<font color=red>User already exists.");
		        	response.getWriter().println("Redirecting to Registration page....");
					response.setHeader("Refresh", "3;url=register.jsp");
		            strUserMsg = "User name "+request.getParameter("userName")+" already " +
		                    "exists. Please try another user name.";
		        } else { //If other SQLException than dup key exception
		            strUserMsg = "Unable to register user "+request.getParameter("userName")+
		            ". Please try again later.";
		        }
		        
			e.printStackTrace();
		}

	
	}

	

}
