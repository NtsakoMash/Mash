package serve;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

/**
 * Servlet implementation class Rate_Calc
 */
public class Rate_Calc extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Rate_Calc() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String bookingdate=null;
		String from=null;
		String to= null;
		String promotioncode=null;
		String class1=null;
		int adult=0;
		int children=0;
		int infants=0;
		int day=0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e11) {
			// TODO Auto-generated catch block
			e11.printStackTrace();
		}
		java.sql.Connection conn = null;
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/airdb [airdb]");
		} catch (SQLException e10) {
			// TODO Auto-generated catch block
			e10.printStackTrace();
		}
		promotioncode=request.getParameter("pc");
		String day1=request.getParameter("day");
		day=Integer.parseInt(day1);
		String adult1=request.getParameter("adultI2");
		adult=Integer.parseInt(adult1);
		String children1=request.getParameter("childI2");
		children=Integer.parseInt(children1);
		String infant1=request.getParameter("infantI2");
		infants=Integer.parseInt(infant1);
		from=request.getParameter("from");
		to=request.getParameter("to");
		class1=request.getParameter("class1");
		java.sql.Statement st2 = null;
		try {
			st2 = conn.createStatement();
		} catch (SQLException e9) {
			// TODO Auto-generated catch block
			e9.printStackTrace();
		}
		ResultSet rs2=null;
		try{
			rs2 = st2.executeQuery("select * from pricelist where from_s='"+from+"' and to_d='"+to+"'");
		}catch(Exception e){
			e.printStackTrace();
		}
		int adultp=0,childp=0,infantp=0;
		try {
			if(rs2.next()){
				adultp=rs2.getInt(3);
				childp=rs2.getInt(4);
				try {
					infantp=rs2.getInt(5);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (SQLException e8) {
			// TODO Auto-generated catch block
			e8.printStackTrace();
		}
		int aIprice=(adult*adultp)+(children*childp)+(infants*infantp);
		if(class1.equals("Economy")) aIprice-=(aIprice*0.2);	//class
		else if(class1.equals("Business")) aIprice-=(aIprice*0.1);
		if(promotioncode.equals("eminem_rocks"))	//promotion code
			aIprice-=(aIprice*0.1);
		else if(promotioncode.equals("signup10"))	//day taxes
			aIprice-=(aIprice*0.1);
		if(day%2==0) aIprice+=aIprice*0.001;
		else aIprice+=aIprice*0.002;

		java.sql.Statement st3 = null;
		try {
			st3 = conn.createStatement();
		} catch (SQLException e7) {
			// TODO Auto-generated catch block
			e7.printStackTrace();
		}
		ResultSet rs3=null;
		try{
			rs3 = st3.executeQuery("select * from pricelist1 where from_s='"+from+"' and to_d='"+to+"'");
		}catch(Exception e){
			e.printStackTrace();
		}
		int adultp1=0,childp1=0,infantp1=0;
		try {
			if(rs3.next()){
				try {
					adultp1=rs3.getInt(3);
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				try {
					childp1=rs3.getInt(4);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					infantp1=rs3.getInt(5);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (SQLException e6) {
			// TODO Auto-generated catch block
			e6.printStackTrace();
		}
		int japrice=(adult*adultp1)+(children*childp1)+(infants*infantp1);
		if(class1.equals("Economy")) japrice-=(japrice*0.2);
		else if(class1.equals("Business")) japrice-=(japrice*0.1);
		if(promotioncode.equals("eminem_rocks"))
			japrice-=(japrice*0.1);
		else if(promotioncode.equals("signup10"))
			japrice-=(japrice*0.1);
		if(day%2==0) japrice+=japrice*0.001;
		else japrice+=japrice*0.002;
		
		
		java.sql.Statement st4 = null;
		try {
			st4 = conn.createStatement();
		} catch (SQLException e5) {
			// TODO Auto-generated catch block
			e5.printStackTrace();
		}
		ResultSet rs4=null;
		try{
			rs4 = st4.executeQuery("select * from pricelist2 where from_s='"+from+"' and to_d='"+to+"'");
		}catch(Exception e){
			e.printStackTrace();
		}
		int adultp2=0,childp2=0,infantp2=0;
		try {
			if(rs4.next()){
				try {
					adultp2=rs4.getInt(3);
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				try {
					childp2=rs4.getInt(4);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					infantp2=rs4.getInt(5);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (SQLException e4) {
			// TODO Auto-generated catch block
			e4.printStackTrace();
		}
		int igprice=(adult*adultp2)+(children*childp2)+(infants*infantp2);
		if(class1.equals("Economy")) igprice-=(igprice*0.2);
		else if(class1.equals("Business")) igprice-=(igprice*0.1);
		if(promotioncode.equals("eminem_rocks"))
			igprice-=(igprice*0.1);
		else if(promotioncode.equals("signup10"))
			igprice-=(igprice*0.1);
		if(day%2==0) igprice+=igprice*0.001;
		else igprice+=igprice*0.002;


		java.sql.Statement st5 = null;
		try {
			st5 = conn.createStatement();
		} catch (SQLException e3) {
			// TODO Auto-generated catch block
			e3.printStackTrace();
		}
		ResultSet rs5=null;
		try{
			rs5 = st5.executeQuery("select * from pricelist3 where from_s='"+from+"' and to_d='"+to+"'");
		}catch(Exception e){
			e.printStackTrace();
		}
		int adultp3=0,childp3=0,infantp3=0;
		try {
			if(rs5.next()){
				try {
					adultp3=rs5.getInt(3);
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				try {
					childp3=rs5.getInt(4);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				try {
					infantp3=rs5.getInt(5);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int sjprice=(adult*adultp3)+(children*childp3)+(infants*infantp3);
		if(class1.equals("Economy")) sjprice-=(sjprice*0.2);
		else if(class1.equals("Business")) sjprice-=(sjprice*0.1);
		if(promotioncode.equals("eminem_rocks"))
			sjprice-=(sjprice*0.1);
		else if(promotioncode.equals("signup10"))
			sjprice-=(sjprice*0.1);
		if(day%2==0) sjprice+=sjprice*0.001;
		else sjprice+=sjprice*0.002;
		
		
		request.setAttribute("aIprice",aIprice);
		request.setAttribute("japrice",japrice);
		request.setAttribute("igprice",igprice);
		request.setAttribute("sjprice",sjprice);
		request.getRequestDispatcher("inventory1.jsp").forward(request, response);

		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
