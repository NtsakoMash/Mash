package serve;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PD
 */
public class PD extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PD() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String bookingno=request.getParameter("book1");
		String adults=request.getParameter("slct");
		String children=request.getParameter("slct1");
		String infants=request.getParameter("slct2");
		String adl1=request.getParameter("adl1");
		String adl2=request.getParameter("adl2");
		String adl3=request.getParameter("adl3");
		String cld1=request.getParameter("cld1");
		String cld2=request.getParameter("cld2");
		String cld3=request.getParameter("cld3");
		String inf1=request.getParameter("inf1");
		String inf2=request.getParameter("inf2");
		String inf3=request.getParameter("inf3");
		
		String adl11=request.getParameter("adl11");
		String adl12=request.getParameter("adl12");
		String adl13=request.getParameter("adl13");
		String cld11=request.getParameter("cld11");
		String cld12=request.getParameter("cld12");
		String cld13=request.getParameter("cld13");
		String inf11=request.getParameter("inf11");
		String inf12=request.getParameter("inf12");
		String inf13=request.getParameter("inf13");
		
		String adl21=request.getParameter("adl21");
		String adl22=request.getParameter("adl22");
		String adl23=request.getParameter("adl23");
		String cld21=request.getParameter("cld21");
		String cld22=request.getParameter("cld22");
		String cld23=request.getParameter("cld23");
		String inf21=request.getParameter("inf21");
		String inf22=request.getParameter("inf22");
		String inf23=request.getParameter("inf23");
		
		String adl31=request.getParameter("adl31");
		String adl32=request.getParameter("adl32");
		String adl33=request.getParameter("adl33");
		String cld31=request.getParameter("cld31");
		String cld32=request.getParameter("cld32");
		String cld33=request.getParameter("cld33");
		String inf31=request.getParameter("inf31");
		String inf32=request.getParameter("inf32");
		String inf33=request.getParameter("inf33");
		
		String date=null;
		request.setAttribute("bookingotp",bookingno);
	
	try {
		Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	java.sql.Connection conn = null;
	try {
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/airdb [airdb]");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	

	
	
	Statement st1 = null;
	try {
		st1 = conn.createStatement();
	} catch (SQLException e2) {
		// TODO Auto-generated catch block
		e2.printStackTrace();
	}
	ResultSet rs1=null;
	try{
		rs1 = st1.executeQuery("select * from booking1 where bookingno='"+bookingno+"'");
	}catch(Exception e){
		e.printStackTrace();
	}

	try {
		if(rs1.next()){
			date=rs1.getString(3)+" "+rs1.getString(4)+" "+rs1.getString(5);
			
			
		}else{
			rs1 = st1.executeQuery("select * from booking2 where bookingno='"+bookingno+"'");
			if(rs1.next()){
				date=rs1.getString(3)+" "+rs1.getString(4)+" "+rs1.getString(5);
				
			}
		}
	} catch (SQLException e2) {
		// TODO Auto-generated catch block
		e2.printStackTrace();
	}
	
	
	request.setAttribute("date",date);
	
	
	
	Statement st7= null;
	try {
		st7 = conn.createStatement();
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	ResultSet rs7;
	try {
		int i= st7.executeUpdate("insert into passenger_details values('"+bookingno+"','"+adl1+"','"+adl11+"','"+adl12+"','"+adl13+"','"+adl2+"','"+adl21+"','"+adl22+"','"+adl23+"','"+adl3+"','"+adl31+"','"+adl32+"','"+adl33+"','"+cld1+"','"+cld11+"','"+cld12+"','"+cld13+"','"+cld2+"','"+cld21+"','"+cld22+"','"+cld23+"','"+cld3+"','"+cld31+"','"+cld32+"','"+cld33+"','"+inf1+"','"+inf11+"','"+inf12+"','"+inf13+"','"+inf2+"','"+inf21+"','"+inf22+"','"+inf23+"','"+inf3+"','"+inf31+"','"+inf32+"','"+inf33+"')");
		

	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	
	
	
	
	Statement st = null;
	try {
		st = conn.createStatement();
	} catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	ResultSet rs;
	try {
		int i= st.executeUpdate("insert into pd_fl_pay values('"+bookingno+"','"+adults+"','"+children+"','"+infants+"','"+adl1+"','"+adl2+"','"+adl3+"','"+cld1+"','"+cld2+"','"+cld3+"','"+inf1+"','"+inf2+"','"+inf3+"','"+"not selected"+"','"+"not selected"+"','"+"not selected"+"','"+"null"+"')");
		response.getWriter().print("Redirecting....");
		//response.setHeader("Refresh", "3;url=flight_details.jsp");
		request.getRequestDispatcher("flight_details.jsp").forward(request, response);

	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	
	
	

}


}
