package serve;

import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

/**
 * Servlet implementation class Seat_A
 */
public class Seat_A extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Seat_A() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String from=request.getParameter("from");
		String to=request.getParameter("to");
		String date1=request.getParameter("dd1");
		String dd20=request.getParameter("dd2");
		String date3=request.getParameter("dd3");
		String dd2=null;
		if(dd20.equals("01"))
			dd2="January";
		else if(dd20.equals("02"))
			dd2="February";
		else if(dd20.equals("03"))
			dd2="March";
		else if(dd20.equals("04"))
			dd2="April";
		else if(dd20.equals("05"))
			dd2="May";
		else if(dd20.equals("06"))
			dd2="June";
		else if(dd20.equals("07"))
			dd2="July";
		else if(dd20.equals("08"))
			dd2="August";
		else if(dd20.equals("09"))
			dd2="September";
		else if(dd20.equals("10"))
			dd2="October";
		else if(dd20.equals("11"))
			dd2="November";
		else if(dd20.equals("12"))
			dd2="December";
		
		
		
		
		
		
		
		
		
		
		String date=date1+" "+dd2+" "+date3;
		
		
		
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		java.sql.Connection conn = null;
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/airdb [airdb]");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int aseat=150;
		int jseat=230;
		int iseat=120;
		int sseat=100;

		java.sql.Statement st6 = null;
		try {
			st6 = conn.createStatement();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ResultSet rs6=null;
		try{
			rs6 = st6.executeQuery("select * from seats where date='"+date+"' and from_s='"+from+"' and to_d='"+to+"'");
		}catch(Exception e){
			e.printStackTrace();
		}

		try {
			if(rs6.next()){
				aseat=rs6.getInt(2);
				jseat=rs6.getInt(3);
				iseat=rs6.getInt(4);
				sseat=rs6.getInt(5);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		request.setAttribute("aseat",aseat);
		request.setAttribute("jseat",jseat);
		request.setAttribute("iseat",iseat);
		request.setAttribute("sseat",sseat);
		
		request.getRequestDispatcher("inventory4.jsp").forward(request, response);
		
		
		
		
		
		
		
		
		
		
		
	}

}
