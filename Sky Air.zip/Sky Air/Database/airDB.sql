-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.18-log - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             9.4.0.5125
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for airdb
CREATE DATABASE IF NOT EXISTS `airdb` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `airdb`;

-- Dumping structure for table airdb.booking1
CREATE TABLE IF NOT EXISTS `booking1` (
  `from_s` varchar(50) DEFAULT NULL,
  `to_d` varchar(50) DEFAULT NULL,
  `ddt1` varchar(50) DEFAULT NULL,
  `ddt2` varchar(50) DEFAULT NULL,
  `ddt3` varchar(50) DEFAULT NULL,
  `pc` varchar(50) DEFAULT NULL,
  `class` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `bookingno` varchar(50) DEFAULT NULL,
  `time` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table airdb.booking1: ~0 rows (approximately)
/*!40000 ALTER TABLE `booking1` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking1` ENABLE KEYS */;

-- Dumping structure for table airdb.booking2
CREATE TABLE IF NOT EXISTS `booking2` (
  `from_s` varchar(50) DEFAULT NULL,
  `to_d` varchar(50) DEFAULT NULL,
  `ddt1` varchar(50) DEFAULT NULL,
  `ddt2` varchar(50) DEFAULT NULL,
  `ddt3` varchar(50) DEFAULT NULL,
  `adt1` varchar(50) DEFAULT NULL,
  `adt2` varchar(50) DEFAULT NULL,
  `adt3` varchar(50) DEFAULT NULL,
  `pc` varchar(50) DEFAULT NULL,
  `class` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `bookingno` varchar(50) DEFAULT NULL,
  `time` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table airdb.booking2: ~0 rows (approximately)
/*!40000 ALTER TABLE `booking2` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking2` ENABLE KEYS */;

-- Dumping structure for table airdb.feedback
CREATE TABLE IF NOT EXISTS `feedback` (
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(35) DEFAULT NULL,
  `number` varchar(15) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `fno` varchar(15) DEFAULT NULL,
  `dot1` varchar(15) DEFAULT NULL,
  `dot2` varchar(25) DEFAULT NULL,
  `dot3` varchar(15) DEFAULT NULL,
  `tno` varchar(15) DEFAULT NULL,
  `sno` varchar(15) DEFAULT NULL,
  `dets` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table airdb.feedback: ~0 rows (approximately)
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;

-- Dumping structure for table airdb.passenger_details
CREATE TABLE IF NOT EXISTS `passenger_details` (
  `bookingno` varchar(50) DEFAULT NULL,
  `adultname1` varchar(50) DEFAULT NULL,
  `adultage1` varchar(50) DEFAULT NULL,
  `adultgender1` varchar(50) DEFAULT NULL,
  `adultaddress1` varchar(50) DEFAULT NULL,
  `adultname2` varchar(50) DEFAULT NULL,
  `adultage2` varchar(50) DEFAULT NULL,
  `adultgender2` varchar(50) DEFAULT NULL,
  `adultaddress2` varchar(50) DEFAULT NULL,
  `adultname3` varchar(50) DEFAULT NULL,
  `adultage3` varchar(50) DEFAULT NULL,
  `adultgender3` varchar(50) DEFAULT NULL,
  `adultaddress3` varchar(50) DEFAULT NULL,
  `childname1` varchar(50) DEFAULT NULL,
  `childage1` varchar(50) DEFAULT NULL,
  `childgender1` varchar(50) DEFAULT NULL,
  `childaddress1` varchar(50) DEFAULT NULL,
  `childname2` varchar(50) DEFAULT NULL,
  `childage2` varchar(50) DEFAULT NULL,
  `childgender2` varchar(50) DEFAULT NULL,
  `childaddress2` varchar(50) DEFAULT NULL,
  `childname3` varchar(50) DEFAULT NULL,
  `childage3` varchar(50) DEFAULT NULL,
  `childgender3` varchar(50) DEFAULT NULL,
  `childaddress3` varchar(50) DEFAULT NULL,
  `infantname1` varchar(50) DEFAULT NULL,
  `infantage1` varchar(50) DEFAULT NULL,
  `infantgender1` varchar(50) DEFAULT NULL,
  `infantaddress1` varchar(50) DEFAULT NULL,
  `infantname2` varchar(50) DEFAULT NULL,
  `infantage2` varchar(50) DEFAULT NULL,
  `infantgender2` varchar(50) DEFAULT NULL,
  `infantaddress2` varchar(50) DEFAULT NULL,
  `infantname3` varchar(50) DEFAULT NULL,
  `infantage3` varchar(50) DEFAULT NULL,
  `infantgender3` varchar(50) DEFAULT NULL,
  `infantaddress3` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table airdb.passenger_details: ~0 rows (approximately)
/*!40000 ALTER TABLE `passenger_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `passenger_details` ENABLE KEYS */;

-- Dumping structure for table airdb.pd_fl_pay
CREATE TABLE IF NOT EXISTS `pd_fl_pay` (
  `bookingno` varchar(50) DEFAULT NULL,
  `adults` varchar(50) DEFAULT NULL,
  `children` varchar(50) DEFAULT NULL,
  `infants` varchar(50) DEFAULT NULL,
  `ad1` varchar(50) DEFAULT NULL,
  `ad2` varchar(50) DEFAULT NULL,
  `ad3` varchar(50) DEFAULT NULL,
  `ch1` varchar(50) DEFAULT NULL,
  `ch2` varchar(50) DEFAULT NULL,
  `ch3` varchar(50) DEFAULT NULL,
  `in1` varchar(50) DEFAULT NULL,
  `in2` varchar(50) DEFAULT NULL,
  `in3` varchar(50) DEFAULT NULL,
  `fl_id` varchar(50) DEFAULT NULL,
  `price` varchar(50) DEFAULT NULL,
  `method` varchar(50) DEFAULT NULL,
  `cardno` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table airdb.pd_fl_pay: ~0 rows (approximately)
/*!40000 ALTER TABLE `pd_fl_pay` DISABLE KEYS */;
/*!40000 ALTER TABLE `pd_fl_pay` ENABLE KEYS */;

-- Dumping structure for table airdb.pricelist
CREATE TABLE IF NOT EXISTS `pricelist` (
  `from_s` varchar(50) DEFAULT NULL,
  `to_d` varchar(50) DEFAULT NULL,
  `adult` varchar(50) DEFAULT NULL,
  `children` varchar(50) DEFAULT NULL,
  `infants` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table airdb.pricelist: ~12 rows (approximately)
/*!40000 ALTER TABLE `pricelist` DISABLE KEYS */;
INSERT INTO `pricelist` (`from_s`, `to_d`, `adult`, `children`, `infants`) VALUES
	('Johannesburg', 'Durban', '5999', '4999', '999'),
	('Johannesburg', 'Cape Town', '5499', '4499', '899'),
	('Johannesburg', 'Port Elizabeth', '6499', '5499', '1199'),
	('Durban', 'Johannesburg', '5999', '4999', '999'),
	('Cape Town', 'Johannesburg', '5499', '4499', '899'),
	('Port Elizabeth', 'Johannesburg', '6499', '5499', '1199'),
	('Durban', 'Cape Town', '3299', '2299', '599'),
	('Durban', 'Port Elizabeth', '7099', '6099', '1399'),
	('Cape Town', 'Durban', '3299', '2299', '599'),
	('Cape Town', 'Port Elizabeth', '6099', '5099', '1099'),
	('Port Elizabeth', 'Durban', '7099', '6099', '1399'),
	('Port Elizabeth', 'Cape Town', '6899', '5899', '999');
/*!40000 ALTER TABLE `pricelist` ENABLE KEYS */;

-- Dumping structure for table airdb.pricelist1
CREATE TABLE IF NOT EXISTS `pricelist1` (
  `from_s` varchar(50) DEFAULT NULL,
  `to_d` varchar(50) DEFAULT NULL,
  `adult` int(11) DEFAULT NULL,
  `children` int(11) DEFAULT NULL,
  `infants` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table airdb.pricelist1: ~12 rows (approximately)
/*!40000 ALTER TABLE `pricelist1` DISABLE KEYS */;
INSERT INTO `pricelist1` (`from_s`, `to_d`, `adult`, `children`, `infants`) VALUES
	('Johannesburg', 'Durban', 6999, 5999, 1999),
	('Johannesburg', 'Cape Town', 6499, 6499, 1899),
	('Johannesburg', 'Port Elizabeth', 7499, 6499, 2199),
	('Durban', 'Johannesburg', 6999, 5999, 1999),
	('Cape Town', 'Johannesburg', 6499, 5499, 1899),
	('Port Elizabeth', 'Johannesburg', 7499, 6499, 2199),
	('Durban', 'Cape Town', 4299, 3299, 1599),
	('Durban', 'Port Elizabeth', 8099, 7099, 2399),
	('Cape Town', 'Durban', 4299, 3299, 1599),
	('Cape Town', 'Port Elizabeth', 7099, 6099, 2099),
	('Port Elizabeth', 'Durban', 8099, 7099, 2399),
	('Port Elizabeth', 'Cape Town', 7899, 6899, 1999);
/*!40000 ALTER TABLE `pricelist1` ENABLE KEYS */;

-- Dumping structure for table airdb.pricelist2
CREATE TABLE IF NOT EXISTS `pricelist2` (
  `from_s` varchar(50) DEFAULT NULL,
  `to_d` varchar(50) DEFAULT NULL,
  `adult` int(11) DEFAULT NULL,
  `children` int(11) DEFAULT NULL,
  `infants` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table airdb.pricelist2: ~12 rows (approximately)
/*!40000 ALTER TABLE `pricelist2` DISABLE KEYS */;
INSERT INTO `pricelist2` (`from_s`, `to_d`, `adult`, `children`, `infants`) VALUES
	('Johannesburg', 'Durban', 4999, 3999, 599),
	('Johannesburg', 'Cape Town', 4499, 3499, 499),
	('Johannesburg', 'Port Elizabeth', 5499, 4499, 699),
	('Durban', 'Johannesburg', 4999, 3999, 599),
	('Port Elizabeth', 'Johannesburg', 5499, 4499, 699),
	('Cape Town', 'Johannesburg', 4499, 3499, 499),
	('Durban', 'Cape Town', 2299, 1299, 399),
	('Durban', 'Port Elizabeth', 6099, 5099, 899),
	('Cape Town', 'Durban', 2299, 1299, 399),
	('Cape Town', 'Port Elizabeth', 5099, 4099, 799),
	('Port Elizabeth', 'Durban', 6099, 5099, 699),
	('Port Elizabeth', 'Cape Town', 5899, 4899, 599);
/*!40000 ALTER TABLE `pricelist2` ENABLE KEYS */;

-- Dumping structure for table airdb.pricelist3
CREATE TABLE IF NOT EXISTS `pricelist3` (
  `from_s` varchar(50) DEFAULT NULL,
  `to_d` varchar(50) DEFAULT NULL,
  `adult` int(11) DEFAULT NULL,
  `children` int(11) DEFAULT NULL,
  `infants` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table airdb.pricelist3: ~11 rows (approximately)
/*!40000 ALTER TABLE `pricelist3` DISABLE KEYS */;
INSERT INTO `pricelist3` (`from_s`, `to_d`, `adult`, `children`, `infants`) VALUES
	('Johannesburg', 'Durban', 4899, 4089, 599),
	('Johannesburg', 'Cape Town', 4699, 3599, 499),
	('Johannesburg', 'Port Elizabeth', 5699, 4199, 699),
	('Durban', 'Johannesburg', 4899, 3699, 599),
	('Port Elizabeth', 'Johannesburg', 5799, 4599, 699),
	('Cape Town', 'Johannesburg', 4199, 3399, 499),
	('Durban', 'Cape Town', 2199, 1199, 399),
	('Durban', 'Port Elizabeth', 6499, 5199, 899),
	('Cape Town', 'Durban', 2199, 1199, 399),
	('Cape Town', 'Port Elizabeth', 5199, 4399, 799),
	('Port Elizabeth', 'Durban', 5999, 4899, 699),
	('Port Elizabeth', 'Cape Town', 5999, 4699, 599);
/*!40000 ALTER TABLE `pricelist3` ENABLE KEYS */;

-- Dumping structure for table airdb.reg_det
CREATE TABLE IF NOT EXISTS `reg_det` (
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `dob1` varchar(50) DEFAULT NULL,
  `dob2` varchar(50) DEFAULT NULL,
  `dob3` varchar(50) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `sq` varchar(50) DEFAULT NULL,
  `answer` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table airdb.reg_det: ~0 rows (approximately)
/*!40000 ALTER TABLE `reg_det` DISABLE KEYS */;
/*!40000 ALTER TABLE `reg_det` ENABLE KEYS */;

-- Dumping structure for table airdb.seats
CREATE TABLE IF NOT EXISTS `seats` (
  `date` varchar(50) DEFAULT NULL,
  `ai` int(11) DEFAULT NULL,
  `ja` int(11) DEFAULT NULL,
  `ig` int(11) DEFAULT NULL,
  `sj` int(11) DEFAULT NULL,
  `from_s` varchar(50) DEFAULT NULL,
  `to_d` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table airdb.seats: ~0 rows (approximately)
/*!40000 ALTER TABLE `seats` DISABLE KEYS */;
/*!40000 ALTER TABLE `seats` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
